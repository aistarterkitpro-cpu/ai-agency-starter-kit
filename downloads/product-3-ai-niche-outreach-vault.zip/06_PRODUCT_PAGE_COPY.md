# Product 3 — Sales Page Copy

## Headline
AI Niche Outreach Vault

## Subheadline
100 outreach scripts + 30 objection replies + discovery call openers + booking templates, ready to copy and customize.

## Who this is for
- Freelancers offering AI services
- Small agencies that need predictable outreach
- Beginners who want proven scripts, not theory

## What’s included
- 100 niche outreach scripts
- 30 objection reply templates
- Discovery call openers by vertical
- CTA and booking message templates

## Outcome
Launch outreach faster, follow up consistently, and book more calls with less guesswork.

## Price
$67 (intro)

## CTA
Get Instant Access

## FAQ
**Do I need technical skills?** No. These are ready-to-use scripts.

**Can I edit these for my niche?** Yes — personalization is encouraged.

**Is this for beginners?** Yes. It’s designed to remove blank-page syndrome.
