# CTA + Booking Message Templates

## Short CTA options
- "Open to a quick 15-minute walkthrough?"
- "Want me to send the exact template stack?"
- "Should I send a one-page action plan for your team?"
- "Worth a quick call this week?"

## Booking link message
"Awesome — here’s my booking link: {{link}}. Pick any time that works and I’ll send a tailored plan before the call."

## Nudge after no response (48h)
"Quick bump in case this got buried — want the template pack or should I close the loop for now?"

## Gentle closeout
"No worries if timing isn’t right. I’ll close this thread for now — happy to reconnect when useful."

## Post-call follow-up
"Great speaking today. As promised, here are the 3 actions to implement first:
1) {{action1}}
2) {{action2}}
3) {{action3}}
If you want, I can share exact scripts for each."
