# 30 Objection Replies (Copy/Paste)

1. **"Too expensive"** → Totally fair. Usually this pays for itself if we recover even 1–2 missed opportunities monthly. Want a smaller pilot first?
2. **"Need to think"** → Makes sense. What specific part should I clarify so you can decide faster?
3. **"Send info"** → Absolutely. Do you prefer a short summary or full breakdown with examples?
4. **"Not now"** → Got it. Should I follow up in 2 weeks or next month?
5. **"We already have someone"** → Great. Want a second-opinion audit so you can benchmark current results?
6. **"No budget"** → Understood. We can start with a low-cost phase focused only on highest-ROI fixes.
7. **"Bad past experience"** → Totally reasonable. I can propose a milestone-based setup with clear checkpoints so risk stays low.
8. **"Too busy"** → I can make this lightweight: 30-minute kickoff, then we handle execution.
9. **"Need partner approval"** → Want me to send a one-page summary you can forward?
10. **"Email me later"** → Sure — what date should I send it so timing is right?
11. **"Not convinced"** → Fair. Want a concrete before/after example from a similar business type?
12. **"We do this manually"** → Manual works until follow-up slips. This just makes it consistent.
13. **"Concerned about AI quality"** → Good point. We keep human review where needed and use AI for speed + consistency.
14. **"No leads anyway"** → Then we can focus on lead capture and first response first.
15. **"Can’t commit"** → We can run a 14-day pilot with clear success metrics.
16. **"Need references"** → I can share sample outputs + process docs today.
17. **"How long to implement?"** → First version can be live in a few days.
18. **"What if it doesn’t work?"** → We set success criteria upfront and adjust quickly if metrics miss.
19. **"Security concerns"** → Valid. We can scope access tightly and document every tool/workflow.
20. **"Too technical"** → I handle setup; your team gets simple SOPs.
21. **"We should wait"** → Waiting usually means more leaked leads. Even a basic setup helps now.
22. **"I hate salesy follow-up"** → Same. Scripts are written to be helpful and human, not pushy.
23. **"Our niche is different"** → Great — templates are customized by niche and offer type.
24. **"Already using CRM"** → Perfect, this improves what happens inside the CRM.
25. **"No bandwidth"** → We can start with just one workflow (missed-call recovery).
26. **"Need exact ROI"** → We’ll track response rate, booked calls, and close rate delta.
27. **"Can we do this in-house?"** → Yes, and I can provide the templates/SOPs so your team owns it.
28. **"Too many tools"** → We keep stack minimal and practical.
29. **"I’m not decision maker"** → No problem — who should I include in next step?
30. **"Circle back later"** → Done. I’ll follow up on {{date}} with a concise update.
