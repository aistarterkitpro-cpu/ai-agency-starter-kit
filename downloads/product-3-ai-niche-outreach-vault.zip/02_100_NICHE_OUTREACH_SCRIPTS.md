# 100 Niche Outreach Scripts

Use this format:
- Personalize first line
- Keep ask simple (15-min call)
- Include one concrete outcome

## 1) Med Spa
1. Hi {{name}} — quick note: most med spas leak leads between IG DMs and front desk follow-up. I help automate follow-up so consults get booked faster. Open to a 15-min walkthrough?
2. Hey {{name}}, your before/after content is strong. If you want, I can show you a simple AI intake + reminder flow that usually lifts consult bookings 15–30%. Worth a quick call?
3. Noticed {{business}} has great reviews. I build no-show recovery follow-up for med spas (text + email). Want a free mini-audit?
4. I help med spas turn missed calls into booked consults with instant text-back and follow-up sequences. Want the template stack?
5. If you’re open, I can send the exact script we use to revive cold leads after 7+ days.
6. Quick idea for {{business}}: AI pre-qualifies prospects before staff calls, cutting admin time. Want the setup map?
7. You’re probably paying for traffic already — I can help squeeze more bookings from existing leads first.
8. I built a 3-message med spa sequence that brings back inactive leads. Want me to share?
9. If lead response time is over 5 mins, conversion drops hard. I can help automate first response.
10. Open to seeing a same-day consult booking workflow for med spas?

## 2) Dental
11. Hi {{name}}, I help dental clinics recover missed-call revenue with instant callback texts and follow-up. Open to a quick call?
12. Most clinics lose high-intent patients after hours. I can show an AI front-desk follow-up flow that fixes that.
13. I made a dental reactivation sequence for overdue hygiene patients. Want the template?
14. If you’re trying to fill schedule gaps, I can show an automated cancellation-fill workflow.
15. Quick idea: auto-response + booking links for voicemail leads. Worth 15 mins?
16. I help practices convert web inquiries faster with structured reply scripts.
17. Could I send over a mini plan to increase consult bookings without buying more ads?
18. I’ve got a 5-touch sequence for treatment plan follow-up if useful.
19. I can map your no-show recovery funnel in one page.
20. Open to a free lead-response audit?

## 3) Real Estate
21. I help agents revive stale leads with AI-assisted follow-up texts and nurture.
22. Want the exact script for old Zillow lead reactivation?
23. Most leads die from slow follow-up; I automate first 24h outreach.
24. I can share a listing-inquiry script that gets more showings booked.
25. Open to a quick walkthrough of an open-house lead nurture flow?
26. I built a seller lead qualification script that saves time.
27. If your CRM is full of “cold” leads, I can help warm them back up.
28. I can show you a 7-day follow-up cadence that feels human.
29. Want a simple appointment-setting sequence for buyers?
30. I’ll send you 3 message templates you can use today if helpful.

## 4) Roofing / Home Services
31. I help roofers turn inbound inquiries into booked inspections faster.
32. Most home service leads go cold after one missed call — I fix that with automation.
33. Want a same-day estimate follow-up script?
34. I can share a seasonal outreach script for storm-damage leads.
35. Quick idea: quote follow-up sequence to raise close rate.
36. Open to a no-obligation lead process review?
37. I’ve got a script to handle “let me think about it” objections.
38. I can help your team follow up every lead in under 2 mins.
39. Want the 5-message “ghosted estimate” sequence?
40. I can show how to increase booked appointments without extra ad spend.

## 5) Legal
41. I help firms respond to web leads instantly and pre-qualify before consult calls.
42. Want an intake follow-up script for personal injury/family law?
43. I can map a missed-call callback process for new matters.
44. Quick idea: consultation reminder flow to reduce no-shows.
45. Open to reviewing your current lead-to-consult pipeline?
46. I built a 3-stage sequence for unresponsive prospects.
47. I can share messaging that balances professionalism + urgency.
48. Most firms lose leads on nights/weekends; automation patches that.
49. Want a referral follow-up template too?
50. I can send a one-page legal intake automation blueprint.

## 6) Fitness / Gyms
51. I help gyms convert trial leads into memberships with timed follow-up.
52. Want the “free trial no-show” recovery script?
53. I can share a class-booking follow-up flow for IG/website leads.
54. Quick idea: AI-assisted FAQ + booking sequence.
55. Open to a lead nurture script for personal training offers?
56. Most gyms lose warm leads after day 2 — I fix that sequence.
57. Want a 7-day challenge sign-up script pack?
58. I can help your front desk follow up consistently.
59. I’ve got objection replies for price/time concerns.
60. Can I send over 3 templates you can deploy this week?

## 7) Ecom / DTC
61. I help DTC brands recover abandoned carts with better message timing.
62. Want a post-purchase upsell message sequence?
63. I can share a customer win-back script for 60-day inactive buyers.
64. Quick idea: AI FAQ + support deflection flow.
65. Open to a retention-focused email/SMS sequence review?
66. I built a review-request + UGC prompt script that gets replies.
67. Want to see a simple LTV lift flow?
68. I can map your high-intent shopper follow-up process.
69. I’ll send a 5-message cart recovery sequence if useful.
70. Can we do a quick audit of your conversion leaks?

## 8) Agencies / B2B Services
71. I help agencies tighten lead response and close more discovery calls.
72. Want my follow-up framework for “interested but busy” leads?
73. I can share proposal follow-up scripts that don’t sound pushy.
74. Quick idea: AI pre-call qualification form + sequence.
75. Open to a 15-min breakdown of your pipeline bottlenecks?
76. I built a gentle bump cadence for ghosted prospects.
77. I can send scripts for referral asks after successful delivery.
78. Want a retainer renewal message framework?
79. I can help reduce manual chasing with templates + automations.
80. I’ll share our close-lost reactivation script pack.

## 9) Local SMB Generic
81. I help local businesses book more appointments from existing leads.
82. Want a missed-call recovery setup you can run this week?
83. I can send a follow-up pack by industry if helpful.
84. Quick question: are you happy with current lead conversion rate?
85. I help teams follow up faster without hiring extra staff.
86. Want a free 5-point lead process audit?
87. I built scripts for first touch, follow-up, and objections.
88. Open to seeing how similar businesses are improving booking rates?
89. I can send a one-page action plan tailored to {{business}}.
90. Worth a short chat to spot easy revenue leaks?

## 10) Re-engagement / Warm intros
91. Quick bump on this — should I close the loop or send the template set?
92. No worries if timing is off; want me to circle back next month?
93. Can I send a short Loom with the exact workflow?
94. If useful, I can give you the scripts free and you can DIY.
95. Do you want the “missed-call recovery” template I mentioned?
96. Should I send examples specific to your niche?
97. Totally fine if now isn’t ideal — would Q2 be better?
98. Happy to share a one-page process map if that helps.
99. Last nudge — want the swipe file before I archive this?
100. Closing this out for now. If you want the templates later, I can send anytime.
