# Discovery Call Openers by Vertical

## Universal opener
"Thanks for jumping on. In 15 minutes, I want to understand your current lead flow, where conversions leak, and show one practical workflow you can implement immediately. Sound good?"

## Med Spa
"How are most of your consults currently booked — DMs, calls, or forms — and where do you feel prospects drop off most?"

## Dental
"When someone calls after hours or misses your first callback, what usually happens next?"

## Real Estate
"How quickly are new leads contacted today, and what follow-up cadence are you using in week one?"

## Roofing/Home Services
"For estimate requests, what percentage gets a same-day response right now?"

## Legal
"How are web leads triaged before consults, and where are intake bottlenecks today?"

## Fitness/Gym
"What’s your current conversion from trial lead to paid member, and where do people stall?"

## DTC/Ecom
"Where do you see the biggest retention leak right now — abandoned carts, post-purchase, or win-back?"

## Agency/B2B
"What stage loses most opportunities for you: first reply, follow-up, proposal, or close?"
