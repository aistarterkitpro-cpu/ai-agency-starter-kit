# Client Proposal Template

## Overview
This proposal outlines how we will implement an AI solution for **[Client Name]**.

## Objectives
- Increase lead capture and response speed
- Reduce manual admin workload
- Improve conversion consistency

## Scope of Work
### Phase 1 — Discovery
- Stakeholder call
- Workflow mapping
- Success metrics definition

### Phase 2 — Build
- Tool configuration
- Prompt/logic setup
- QA + revisions

### Phase 3 — Launch
- Go-live support
- 7-day monitoring
- Handover documentation

## Timeline
- Start: [Date]
- Delivery: [Date]

## Investment
- Setup fee: $[amount]
- Optional retainer: $[amount]/month

## Terms
- 50% upfront, 50% on delivery
- Two rounds of revisions included
- Additional scope billed separately
