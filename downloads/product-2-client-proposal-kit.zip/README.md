# Client Proposal + Invoice Kit ($47)

Includes:
- Proposal template (short + long form)
- Scope of Work template
- Change order template
- Invoice template (one-time + retainer)
- Follow-up email sequence (proposal sent, nudge, final bump)
