# Scope of Work (SOW)

## Client
- Name: [Client Name]
- Project: [Project Name]

## Deliverables
1. [Deliverable 1]
2. [Deliverable 2]
3. [Deliverable 3]

## Timeline
- Kickoff: [Date]
- Delivery: [Date]

## Revisions
- Includes up to 2 revision rounds.

## Payment
- 50% upfront
- 50% on delivery
