# Invoice Template

**Invoice #:** [INV-0001]
**Date:** [YYYY-MM-DD]
**Client:** [Client Name]

## Line Items
- AI Setup Package — $[amount]
- Additional Services — $[amount]

**Subtotal:** $[amount]
**Tax:** $[amount]
**Total:** $[amount]

## Payment Terms
- Due on receipt / Net 7 / Net 15
- Late fee: 5% after 30 days

## Payment Method
- Stripe payment link or bank transfer
