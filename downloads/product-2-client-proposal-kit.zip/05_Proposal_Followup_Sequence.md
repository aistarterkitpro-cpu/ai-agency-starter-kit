# Proposal Follow-Up Sequence

## Follow-up 1 (48h)
Subject: Quick follow-up on your proposal

Hi [Name], just checking if you had any questions on the proposal I sent.

## Follow-up 2 (Day 4)
Subject: Should I close this out?

Totally okay if timing changed. If helpful, I can suggest a smaller starter scope.

## Follow-up 3 (Day 7)
Subject: Final follow-up

Closing this loop for now. If you want to restart, reply "ready" and I'll prioritize it.
